#ifndef MATRIXCONSTRUCTOR_H_
#define MATRIXCONSTRUCTOR_H_

void construct_poissonmatrix(int firstrowindex, int firstgrid_x, int lastgrid_x, int numgrid_x, int numgrid_y, double *poissonmatrix);

#endif
